package tuyentv.fpoly.demo.demo3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import tuyentv.fpoly.demo.R;

public class Demo31Main2Activity extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main2);
        listView = findViewById(R.id.listview);
        getContacts();
    }

    @SuppressLint("Range")
    public void getContacts() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.READ_CONTACTS
            }, 999);
        } else {
            Uri uri = Uri.parse("content://com.android.contacts/contacts");//duong dan
            ArrayList list = new ArrayList();
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();//di chuyển về bản ghi đầu tiên
                //đọc dữ liệu
                while (cursor.isAfterLast()) {//nếu không phải bản ghi cuối cùng, thì tiếp tục đọc
                    //lấy số thứ tự trong danh bạ
                    @SuppressLint("Range") String thutu = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    //lấy tên của bản ghi
                    @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    //lấy số điện thoại
                    Cursor cursorNumber = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{
                            ContactsContract.CommonDataKinds.Phone.NUMBER
                    }, ContactsContract.CommonDataKinds.Phone.CONTACT_ID+" =? AND"+
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE + " = " +
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE, new String[]{thutu}, null);
                    String contactNumber = null;
                    if(cursorNumber.moveToFirst()){
                        contactNumber = cursorNumber.getString(cursorNumber.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    }
                    cursorNumber.close();
                    //kết quả cuối cùng
                    String thuTu_ten = thutu+" - "+name+" - "+contactNumber;
                    //đưa vào list
                    list.add(thuTu_ten);
                    //di chuyển con trỏ đến bản ghi tiếp theo
                    cursor.moveToFirst();
                }//đóng con trỏ ở hàng
                cursor.close();
                ArrayAdapter<String> adapter = new ArrayAdapter<>(Demo31Main2Activity.this, android.R.layout.simple_list_item_1, list);
                listView.setAdapter(adapter);
            }
        }
    }
}