package tuyentv.fpoly.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Intent: Vận chuyển dữ liệu
        // Activity: giao tiếp với người dùng
        //Service: Chạy ngầm trong hệ thống(lắng nghe)
        //Broadcast: Nhận và phát thông điệp do service, activity cung cấp
        //Content Provider: trình quản lý nội dung(giống như 1 cơ sqlite dùng lưu thông tin cấu hình)

    }
}