package tuyentv.fpoly.demo.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import tuyentv.fpoly.demo.R;

public class Demo22Main2Activity extends AppCompatActivity {
    Button btn;
    EditText txt1;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main2);
        context=this;
        btn = findViewById(R.id.btndemo22);
        txt1 = findViewById(R.id.demo22txt1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Lấy dữ liệu người dùng
                String dulieu = txt1.getText().toString();
                //truyền dữ liệu cho intent
                Intent intent = new Intent(context, MyBroadcart2.class);
                intent.putExtra("br", dulieu);
                //yêu cầu broadcart
                sendBroadcast(intent);
            }
        });
    }
}