package tuyentv.fpoly.demo.demo1;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService3 extends Service {
    int count = 0;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        String ten = intent.getStringExtra("tensv");
        char[] chars = ten.toCharArray();
        for (int i = 0; i<chars.length; i++){
            if(chars[i] == 'a'){
                count++;
            }
        }
        Toast.makeText(this, "so luong ki tu a la: "+count, Toast.LENGTH_SHORT).show();
        count =0;
        return super.onStartCommand(intent, flags, startId);
    }
}
