package tuyentv.fpoly.demo.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import tuyentv.fpoly.demo.R;

public class Demo1MainActivity extends AppCompatActivity {
    EditText txt1, txt2;
    Button btnStart, btnStop, btnDem;
    Intent intent1, intent2, intent3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo1_main);
        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);

        btnStart = findViewById(R.id.button);
        btnStop = findViewById(R.id.button2);
        btnDem = findViewById(R.id.dem);

        intent1 = new Intent(this,MyService1.class);
        intent2 = new Intent(this,MyService2.class);
        intent3 = new Intent(this, MyService3.class);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startService(intent1);
                //lấy dữ liệu người dùng nhập
                String masv = txt1.getText().toString();
                String tensv = txt2.getText().toString();
                //2.đưa vào intent
                intent2.putExtra("masv", masv);
                intent2.putExtra("tensv", tensv);
                //3.gọi service
                startService(intent2);
            }
        });

        btnDem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tensv = txt2.getText().toString();
                intent3.putExtra("tensv", tensv);
                startService(intent3);
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //stopService(intent1);
                stopService(intent2);
            }
        });
    }
}